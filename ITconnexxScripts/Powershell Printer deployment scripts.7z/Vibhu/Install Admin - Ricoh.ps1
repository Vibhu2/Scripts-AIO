Set-ExecutionPolicy Bypass -scope Process -Force
Invoke-Command {pnputil.exe -a "\\192.168.201.30\install\Printer Drivers\Ricoh C4504\disk1\oemsetup.inf" }
Add-PrinterDriver -Name "RICOH MP C4504 PCL 6"
Add-PrinterPort -Name "IP_192.168.1.48" -PrinterHostAddress "192.168.1.48"
Start-Sleep 10
Add-Printer -DriverName "RICOH MP C4504 PCL 6" -Name "Admin - Ricoh Color" -PortName IP_192.168.1.48

<#
Remove-Printer -Name "Admin - Ricoh Color"
Remove-PrinterPort -Name "IP_192.168.1.48" 
Remove-PrinterDriver -Name "RICOH MP C4504 PCL 6"
#>