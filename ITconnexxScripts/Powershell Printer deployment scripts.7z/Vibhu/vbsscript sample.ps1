﻿#https://lazyadmin.nl/it/install-and-add-network-printers-from-the-command-line/

cscript "C:\Windows\System32\Printing_Admin_Scripts\en-US\prndrvr.vbs" -a -m "RICOH MP C4504 PCL 6" -h "\\192.168.201.30\install\Printer Drivers\Ricoh C4504\disk1\" -i "oemsetup.inf"
Cscript "C:\Windows\System32\Printing_Admin_Scripts\en-US\Prnport.vbs" -a -r TCPPort:192.168.1.48 -h 192.168.1.48 -o raw -n 9100
Cscript "C:\Windows\System32\Printing_Admin_Scripts\en-US\Prnmngr.vbs" -a -p "RICOH MP C4504" -m "RICOH MP C4504 PCL 6" -r 192.168.1.48