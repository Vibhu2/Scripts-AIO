Set-ExecutionPolicy Bypass -scope Process -Force
Invoke-Command {pnputil.exe -a "\\192.168.201.30\install\Printer Drivers\HP Universal Printing PCL6\hpcu250u.inf" }
Add-PrinterDriver -Name "HP Universal Printing PCL 6"
Add-PrinterPort -Name "IP_192.168.3.65" -PrinterHostAddress "192.168.3.65"
Start-Sleep 10
Add-Printer -DriverName "HP Universal Printing PCL 6" -Name "HP Color Laserjet" -PortName IP_192.168.3.65

<#
Remove-Printer -Name "HP Color Laserjet"
Remove-PrinterPort -Name "IP_192.168.3.65" 
Remove-PrinterDriver -Name "HP Universal Printing PCL 6"
#>