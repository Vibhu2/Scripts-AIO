Set-ExecutionPolicy Bypass -scope Process -Force
Invoke-Command {pnputil.exe -a "\\192.168.201.30\install\Printer Drivers\Ricoh C2004\disk1\oemsetup.inf" }
Add-PrinterDriver -Name "RICOH MP C2004 PCL 6"
Add-PrinterPort -Name "IP_192.168.3.47" -PrinterHostAddress "192.168.3.47"
Start-Sleep 10
Add-Printer -DriverName "RICOH MP C2004 PCL 6" -Name "Nagel - Ricoh Color" -PortName IP_192.168.3.47

<#
Remove-Printer -Name "Nagel - Ricoh Color"
Remove-PrinterPort -Name "IP_192.168.3.47" 
Remove-PrinterDriver -Name "RICOH MP C2004 PCL 6"
#>